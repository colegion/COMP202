package code;

/* Modify this file using the following info
 * - Angora is a Cat breed  
 * - Angora is not considered a wild cat
 * - Angora moves with 15 units of speed
 * - Angora makes a "meow" sound
 * - Angora cats may have differently colored eyes  (Hint: add this to its description)
 * 
 * */

public class Angora extends Cat {
	protected String breed = "Angora";
	protected String sound = "meow";
	
	public Angora() {
		super();
		this.moveSpeed = 15;
	}
	
	public Angora(String breed , String sound) {
		super();
		this.breed = "Angora";
		this.sound = "meow";
	}
	
	public void makeSound() {
		super.makeSound();
	}
	
	public void description() {
		makeSound();
		System.out.println("Angora cats may have differently colored eyes ");
	}

	
	public boolean isWild() {
		return super.isWild();
	}
	
	
}
