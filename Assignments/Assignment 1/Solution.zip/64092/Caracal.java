package code;

/* Modify this file using the following info
 * - Caracal is a Cat breed  
 * - Caracal is considered a wild cat
 * - Caracal moves with 22 units of speed
 * - Caracal makes a "hiss" sound
 * - Caracal cats have longer ears (Hint: add this to its description)
 * 
 * */


public class Caracal extends Cat {
	protected String breed = "Caracal";
	protected String sound = "hiss";
	
	public Caracal() {
		super();
		this.moveSpeed = 22;
	}
	
	public Caracal(String breed , String sound) {
		super();
		this.breed = "Caracal";
		this.sound = "hiss";
	}
	
	public void makeSound() {
		super.makeSound();
	}

	@Override
	public void description() {
		makeSound();
		System.out.println("Caracal cats have longer ears");
	}


	@Override
	public boolean isWild() {
		return true;
	}

	@Override
	public void run() {
		super.run();
	}

	@Override
	public void sleep(int sleepHour) {
		super.sleep(sleepHour);
	}
	

}
