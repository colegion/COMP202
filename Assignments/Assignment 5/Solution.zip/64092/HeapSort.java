package code;

import given.AbstractArraySort;

/*
 * Implement the heap-sort algorithm here. You can look at the slides for the pseudo-code.
 * Make sure to use the swap and compare functions given in the AbstractArraySort!
 * 
 */

public class HeapSort<K extends Comparable<K>> extends AbstractArraySort<K> {

  // Add any fields here
  int s;

  public HeapSort() {
    name = "Heapsort";

    // Initialize anything else here
  }

  @Override
  public void sort(K[] inputArray) {
    // TODO: Implement the heap-sort algorithm
	  heapify(inputArray);
	  s = inputArray.length - 1;
	  while(s > 0) {
		  swap(inputArray, 0, s);
		  s--;
		  downheap2(inputArray, 0, s);
	  }

  }

  private void downheap2(K[] inputArray, int i, int s) {
	// TODO Auto-generated method stub
	int index = i;
	int lChild = 2 * index + 1;
	int rChild = 2 * index + 2;
	if(lChild <= s && compare(inputArray[index], inputArray[lChild]) < 0) {
		index = lChild;
	}
	if(rChild <= s && compare(inputArray[index], inputArray[rChild]) < 0) {
		index = rChild;
	}
	if(index != i) {
		swap(inputArray, i, index);
		downheap2(inputArray, index, s);
	}
}

// Public since we are going to check its output!
  public void heapify(K[] inputArray) {
    // TODO: Heapify the array. See the slides for an O(n) version which uses
    // downheap
	  for(int i = inputArray.length /2 -1; i >= 0; i--) {
		  downheap2(inputArray, i, inputArray.length -1);
	  }

  }
  
  // The below methods are given given as suggestion. You do not need to use them.
  // Feel free to add more methods

  protected void downheap(K[] inputArray, int i) {
    // TODO: Implement the downheap method to help with the algorithm
	  downheap2(inputArray, i, s);
  }
}
