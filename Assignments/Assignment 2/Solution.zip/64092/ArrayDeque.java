package code;

/* 
 * ASSIGNMENT 2
 * AUTHOR:  <Insert Student Name>
 * Class : ArrayDeque
 *
 * You are not allowed to use Java containers!
 * You must implement the Array Deque yourself
 *
 * MODIFY 
 * 
 * */

import given.iDeque;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Iterator;

import given.Util;


/*
 * You must have a circular implementation. 
 * 
 * WARNING: Modulo operator (%) might create issues with negative numbers.
 * Use Math.floorMod instead if you are having issues
 */
public class ArrayDeque<E> implements iDeque<E> {

  private E[] A; //Do not change this name!
  private int head;
  private int tail;
  private int size;
  /*
   * ADD FIELDS IF NEEDED
   */
	
	public ArrayDeque() {
		this(1000);
		head = -1;
		tail = -1;
		size = 0;
    /*
     * ADD CODE IF NEEDED
     */
	}
	
	public ArrayDeque(int initialCapacity) {
	   if(initialCapacity < 1)
	      throw new IllegalArgumentException();
		A = createNewArrayWithSize(initialCapacity);
		
		/*
		 * ADD CODE IF NEEDED
		 */
	}
	
	// This is given to you for your convenience since creating arrays of generics is not straightforward in Java
	@SuppressWarnings({"unchecked" })
  private E[] createNewArrayWithSize(int size) {
	  return (E[]) new Object[size];
	}
	
	//Modify this such that the dequeue prints from front to back!
	//Hint, after you implement the iterator, use that!
  public String toString() {
    if(isEmpty()) {
    	return "";
    }
    StringBuilder sb = new StringBuilder(1000);
    sb.append("[");
    Iterator<E> iter = Arrays.asList(A).iterator();
    while(iter.hasNext()) {
      E e = iter.next();
      if(e == null)
        continue;
      sb.append(e);
      if(!iter.hasNext())
        sb.append("]");
      else
        sb.append(", ");
    }
    return sb.toString();
  }
	
 public void resizeDeque() {
	 E[] newDeque = createNewArrayWithSize(A.length * 2);
	 for(int i = 0 ; i < A.length - 1 ; i++) {
		 int j = Math.floorMod(head + i, A.length);
		 newDeque[i] = A[j];
	 }
	 head = 0;
	 A = newDeque;
 }
	
	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	public void addFront(E o) {
		if (size() == A.length) {
			resizeDeque();
		}
		if (head == -1 && tail == -1) {
			head = 0;
			tail = 0;
		}
		head = Math.floorMod(head - 1, A.length);
		size++;
		A[head] = o;
	}

	@Override
	public E removeFront() {
		if (isEmpty()) {
			return null;
		}
		E popped = A[head];
		if (head == tail) {
			head = -1;
			tail = -1;
		} else {
			head = Math.floorMod(head + 1, A.length);
		}
		size--;
		return popped;
	}

	@Override
	public E front() {
		return isEmpty() ? null : A[head];
	}

	@Override
	public void addBehind(E o) {
		if (size() == A.length) {
			resizeDeque();
		}
		if (head == -1 && tail == -1) {
			head = 0;
			tail = 0;
		} else {
			tail = Math.floorMod(tail + 1, A.length);
		}
		size++;
		A[tail] = o;
	}

	@Override
	public E removeBehind() {
		if (isEmpty()) {
			return null;
		}
		E removed = A[tail];
		if (head == tail) {
			head = -1;
			tail = -1;
		}
		size--;
		tail = Math.floorMod(tail - 1, A.length);
		
		return removed;
	}

	@Override
	public E behind() {
		return isEmpty() ? null : A[tail];
	}

	@Override
	public void clear() {
		head = -1;
		tail = -1;
		size = 0;
	}

	// Must print from front to back
	@Override
	public Iterator<E> iterator() {
		ArrayDequeIterator iter = new ArrayDequeIterator();
		return iter;
	}

  private final class ArrayDequeIterator implements Iterator<E> {


    @Override
    public boolean hasNext() {
      return head < A.length;
    }

    @Override
    public E next() {
      return A[head++];
    }
  }
}
