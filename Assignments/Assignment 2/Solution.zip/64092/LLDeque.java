package code;

/* 
 * ASSIGNMENT 2
 * AUTHOR:  <Insert Student Name>
 * Class : LLDeque
 *
 * You are not allowed to use Java containers!
 * You must implement the linked list yourself
 * Note that it should be a doubly linked list
 *
 * MODIFY 
 * 
 * */

import given.iDeque;
import java.util.Iterator;
import given.Util;

//If you have been following the class, it should be obvious by now how to implement a Deque wth a doubly linked list
public class LLDeque<E> implements iDeque<E> {

	// Use sentinel nodes. See slides if needed
	private Node<E> header;
	private Node<E> trailer;
	private int size;

	// The nested node class, provided for your convenience. Feel free to modify
	private class Node<T> {
		private T element;
		private Node<T> next;
		private Node<T> prev;

		Node(T d, Node<T> n, Node<T> p) {
			element = d;
			next = n;
			prev = p;
		}

	}

	public LLDeque() {
		header = new Node<E>(null, null, header);
		trailer = new Node<E>(null, trailer, header);
		header.next = trailer;
		size = 0;

	}

	public String toString() {
		if (isEmpty())
			return "";
		StringBuilder sb = new StringBuilder(1000);
		sb.append("[");
		Node<E> tmp = header.next;
		while (tmp.next != trailer) {
			sb.append(tmp.element.toString());
			sb.append(", ");
			tmp = tmp.next;
		}
		sb.append(tmp.element.toString());
		sb.append("]");
		return sb.toString();
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	public void addFront(E o) {
		Node<E> newNode = new Node<E>(o, null, null);
		newNode.next = header.next;
		newNode.prev = header;
		if (isEmpty()) {
			trailer.prev = header;
			header.next = newNode;
		} else {
			header.next.prev = newNode;
			header.next = newNode;
		}
		size++;
	}

	@Override
	public E removeFront() {
		if (isEmpty()) {
			return null;
		}
		Node<E> temp = header.next;
		header.next = temp.next;
		temp.next.prev = header;
		size--;
		return temp.element;
	}

	@Override
	public E front() {
		if (isEmpty()) {
			return null;
		}
		return header.next.element;
	}

	@Override
	public void addBehind(E o) {
		Node<E> newNode = new Node<E>(o, null, null);
		newNode.next = trailer;
		newNode.prev = trailer.prev;
		if (isEmpty()) {
			trailer.prev = newNode;
			header.next = newNode;
		}
		trailer.prev.next = newNode;
		trailer.prev = newNode;
		size++;
	}

	@Override
	public E removeBehind() {
		if (isEmpty()) {
			return null;
		}
		Node<E> temp = trailer.prev;
		temp.prev.next = trailer;
		trailer.prev = temp.prev;
		size--;
		return temp.element;

	}

	@Override
	public E behind() {
		if (isEmpty()) {
			return null;
		}
		return trailer.prev.element;
	}

	@Override
	public void clear() {
		header = trailer;
		size = 0;
	}

	@Override
	public Iterator<E> iterator() {
		LLDequeIterator iter = new LLDequeIterator();
		return iter;
	}

	private final class LLDequeIterator implements Iterator<E> {
		private Node<E> N = header.next;

		@Override
		public boolean hasNext() {
			return N.next != null;
		}

		@Override
		public E next() {
			return N.element;
		}
	}

}
