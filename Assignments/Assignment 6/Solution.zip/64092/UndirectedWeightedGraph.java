package code;

import java.util.HashMap;
import java.util.Set;

public class UndirectedWeightedGraph<V> extends BaseGraph<V> {

	boolean t ;
	boolean f ;
	private HashMap<V, HashMap<V, Float>> adjacencyM;

	public UndirectedWeightedGraph() {
		 t = true;
		 f = false;
		 adjacencyM = new HashMap<V, HashMap<V, Float>>();
	}

	@Override
	public String toString() {
		return "UndirectedWeightedGraph";
	}

	@Override
	public void insertVertex(V v) {
		if (v == null || adjacencyM.containsKey(v))
			return;
		adjacencyM.put(v, new HashMap<V, Float>());
	}

	@Override
	public V removeVertex(V v) {
		if (adjacencyM.containsKey(v)) {
			V temp = v;
			HashMap<V, Float> neighbors = (HashMap<V, Float>) adjacencyM.get(v).clone();
			for (V vertex : neighbors.keySet()) {
				removeEdge(vertex, v);
			}
			adjacencyM.remove(v);
			return temp;
		}
		return null;
	}

	@Override
	public boolean areAdjacent(V v1, V v2) {
		if (adjacencyM.containsKey(v1))
			return adjacencyM.get(v1).containsKey(v2);
		return false;
	}

	@Override
	public void insertEdge(V source, V target) {
		insertEdge(source, target, 1);
	}

	@Override
	public void insertEdge(V source, V target, float weight) {
		// TODO Auto-generated method stub
		if (!adjacencyM.containsKey(source) || !adjacencyM.containsKey(target)) {
			insertVertex(source);
			insertVertex(target);
		}
		adjacencyM.get(source).put(target, weight);
		adjacencyM.get(target).put(source, weight);

	}

	@Override
	public boolean removeEdge(V source, V target) {
		if (adjacencyM.get(source).containsKey(target) && adjacencyM.get(target).containsKey(source)) {
			adjacencyM.get(source).remove(target);
			adjacencyM.get(target).remove(source);
			return true;
		}
		return false;
	}

	@Override
	public float getEdgeWeight(V source, V target) {
		if (source == null || target == null)
			return 0;
		else if (!areAdjacent(source, target)) {
			return Float.MAX_VALUE;
		}
		if (adjacencyM.get(source).containsKey(target) || adjacencyM.get(target).containsKey(source)) {
			return adjacencyM.get(source).get(target);
		}
		return 0;
	}

	@Override
	public int numVertices() {
		return adjacencyM.size();
	}

	@Override
	public Iterable<V> vertices() {
		return adjacencyM.keySet();
	}

	@Override
	public int numEdges() {
		int numEdges = 0;
		for (V v : vertices()) {
			numEdges += adjacencyM.get(v).size();
		}
		return numEdges / 2;
	}

	@Override
	public boolean isDirected() {
		return f;
	}

	@Override
	public boolean isWeighted() {
		return t;
	}

	@Override
	public int outDegree(V v) {
		if (v == null || !adjacencyM.containsKey(v))
			return -1;
		return ((Set<V>) outgoingNeighbors(v)).size();
	}

	@Override
	public int inDegree(V v) {
		return outDegree(v);
	}

	@Override
	public Iterable<V> outgoingNeighbors(V v) {
		// TODO Auto-generated method stub
		if (v == null || !adjacencyM.containsKey(v))
			return null;
		return adjacencyM.get(v).keySet();
	}

	@Override
	public Iterable<V> incomingNeighbors(V v) {
		return outgoingNeighbors(v);
	}
}
