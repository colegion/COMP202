package code;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class DirectedWeightedGraph<V> extends BaseGraph<V> {

	boolean t;
	boolean f;
	private HashMap<V, HashMap<V, Float >> adjacencyM;

	public DirectedWeightedGraph() {
		adjacencyM = new HashMap<V, HashMap<V, Float>>();
		t = true;
		f = true;
	}

	@Override
	public String toString() {
		return "DirectedWeightedGraph";
	}

	@Override
	public void insertVertex(V v) {
		if (v == null || adjacencyM.containsKey(v))
			return;
		adjacencyM.put(v, new HashMap<V, Float>());
	}

	@Override
	public V removeVertex(V v) {
		if (v == null || !adjacencyM.containsKey(v))
			return null;
		V temp = v;
		for (V vertex : vertices())
			if (adjacencyM.get(vertex).containsKey(v))
				removeEdge(vertex, v);
		adjacencyM.remove(v);
		return temp;
	}

	@Override
	public boolean areAdjacent(V v1, V v2) {
		if (adjacencyM.containsKey(v1) && adjacencyM.containsKey(v2))
			return adjacencyM.get(v1).containsKey(v2) || adjacencyM.get(v2).containsKey(v1);
		return false;
	}

	@Override
	public void insertEdge(V source, V target) {
		insertEdge(source, target, 1);
	}

	@Override
	public void insertEdge(V source, V target, float weight) {
		if (!adjacencyM.containsKey(source) || !adjacencyM.containsKey(target)) {
			insertVertex(source);
			insertVertex(target);
		}
		adjacencyM.get(source).put(target, weight);
	}

	@Override
	public boolean removeEdge(V source, V target) {
		if (!adjacencyM.containsKey(source) || !adjacencyM.containsKey(target) || !adjacencyM.get(source).containsKey(target))
			return false;
		adjacencyM.get(source).remove(target);
		return true;
	}

	@Override
	public float getEdgeWeight(V source, V target) {
		if (source == null || target == null)
			return 0;
		if (!areAdjacent(source, target)) {
			return Float.MAX_VALUE;
		}
		if (adjacencyM.get(source).containsKey(target))
			return adjacencyM.get(source).get(target);
		return 0;
	}

	@Override
	public int numVertices() {
		return adjacencyM.size();
	}

	@Override
	public Iterable<V> vertices() {
		return adjacencyM.keySet();
	}

	@Override
	public int numEdges() {
		int numEdges = 0;
		for (V v1 : vertices()) {
			numEdges += adjacencyM.get(v1).size();
		}
		return numEdges;
	}

	@Override
	public boolean isDirected() {
		return f;
	}

	@Override
	public boolean isWeighted() {
		return t;
	}

	@Override
	public int outDegree(V v) {
		return adjacencyM.containsKey(v) ? ((Set<V>) outgoingNeighbors(v)).size() : -1;
	}

	@Override
	public int inDegree(V v) {
		return adjacencyM.containsKey(v) ? ((ArrayList<V>) incomingNeighbors(v)).size() : -1;
	}

	@Override
	public Iterable<V> outgoingNeighbors(V v) {
		return adjacencyM.containsKey(v) ? adjacencyM.get(v).keySet() : null;
	}

	@Override
	public Iterable<V> incomingNeighbors(V v) {
		if (v == null)
			return null;
		ArrayList<V> neighbors = new ArrayList<V>();
		for (V vertex : vertices()) {
			if (adjacencyM.get(vertex).containsKey(v))
				neighbors.add(vertex);
		}
		return neighbors;
	}
}