package code;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UndirectedUnweightedGraph<V> extends BaseGraph<V> {

	boolean t ;
	boolean f ;
	private HashMap<V, ArrayList<V>> adjacencyM;

	public UndirectedUnweightedGraph() {
		t = false;
		f = false;
		adjacencyM = new HashMap<V, ArrayList<V>>();
	}

	@Override
	public String toString() {
		return "UndirectedUnweightedGraph";
	}

	@Override
	public void insertVertex(V v) {
		if (v == null || adjacencyM.containsKey(v))
			return;
		adjacencyM.put(v, new ArrayList<V>());
	}

	@Override
	public V removeVertex(V v) {
		if (adjacencyM.containsKey(v)) {
			V temp = v;
			List<V> adjacents = (ArrayList<V>) adjacencyM.get(v).clone();
			for (V adj : adjacents) {
				removeEdge(adj, v);
			}
			adjacencyM.remove(v);
			return temp;
		}
		return null;
	}

	@Override
	public boolean areAdjacent(V v1, V v2) {
		if (adjacencyM.containsKey(v1))
			return adjacencyM.get(v1).contains(v2);
		return false;
	}

	@Override
	public void insertEdge(V source, V target) {
		if (!adjacencyM.containsKey(source) || !adjacencyM.containsKey(target)) {
			insertVertex(source);
			insertVertex(target);
		}
		adjacencyM.get(source).add(target);
		adjacencyM.get(target).add(source);
	}

	@Override
	public void insertEdge(V source, V target, float weight) {
		insertEdge(source, target);
	}

	@Override
	public boolean removeEdge(V source, V target) {
		if (adjacencyM.get(source).contains(target) && adjacencyM.get(target).contains(source)) {
			adjacencyM.get(source).remove(target);
			adjacencyM.get(target).remove(source);
			return true;
		}
		return false;
	}

	@Override
	public float getEdgeWeight(V source, V target) {
		// TODO Auto-generated method stub
		if (source == null || target == null || !areAdjacent(source, target))
			return 0;
		return 1;
	}

	@Override
	public int numVertices() {
		return adjacencyM.size();
	}

	@Override
	public Iterable<V> vertices() {
		return adjacencyM.keySet();
	}

	@Override
	public int numEdges() {
		int numEdges = 0;
		for (V v : vertices()) {
			numEdges += adjacencyM.get(v).size();
		}
		return numEdges / 2;
	}

	@Override
	public boolean isDirected() {
		return f;
	}

	@Override
	public boolean isWeighted() {
		return t;
	}

	@Override
	public int outDegree(V v) {
		if (v == null || !adjacencyM.containsKey(v))
			return -1;
		return ((ArrayList<V>) outgoingNeighbors(v)).size();
	}

	@Override
	public int inDegree(V v) {
		return outDegree(v);
	}

	@Override
	public Iterable<V> outgoingNeighbors(V v) {
		if (v == null || !adjacencyM.containsKey(v))
			return null;
		return adjacencyM.get(v);
	}

	@Override
	public Iterable<V> incomingNeighbors(V v) {
		return outgoingNeighbors(v);
	}

}