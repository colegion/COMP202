package code;

import java.util.*;

public class DirectedUnweightedGraph<V> extends BaseGraph<V> {

	boolean t;
	boolean f;
	private HashMap<V, ArrayList<V>> adjacencyM;

	public DirectedUnweightedGraph() {
		adjacencyM = new HashMap<V, ArrayList<V>>();
		t = false;
		f = true;
	}

	@Override
	public String toString() {
		return "DirectedUnweightedGraph";
	}

	@Override
	public void insertVertex(V v) {
		if (adjacencyM.containsKey(v) || v == null)
			return;
		adjacencyM.put(v, new ArrayList<V>());
	}

	@Override
	public V removeVertex(V v) {
		if (v == null || !adjacencyM.containsKey(v))
			return null;
		V temp = v;
		for (V adjacent : vertices())
			if (adjacencyM.get(adjacent).contains(v))
				removeEdge(adjacent, v);
		adjacencyM.remove(v);
		return temp;
	}

	@Override
	public boolean areAdjacent(V v1, V v2) {
		if (adjacencyM.containsKey(v2) && adjacencyM.containsKey(v1))
			return adjacencyM.get(v1).contains(v2) || adjacencyM.get(v2).contains(v1);
		return false;
	}

	@Override
	public void insertEdge(V source, V target) {
		if (!adjacencyM.containsKey(target) || !adjacencyM.containsKey(source)) {
			insertVertex(source);
			insertVertex(target);
		}
		if (!adjacencyM.get(source).contains(target))
			adjacencyM.get(source).add(target);
	}

	@Override
	public void insertEdge(V source, V target, float weight) {
		insertEdge(source, target);
	}

	@Override
	public boolean removeEdge(V source, V target) {
		if (!adjacencyM.containsKey(target) || !adjacencyM.containsKey(source) || !adjacencyM.get(source).contains(target))
			return false;
		adjacencyM.get(source).remove(target);
		return true;
	}

	@Override
	public float getEdgeWeight(V source, V target) {
		if (!areAdjacent(source, target) || source == null || target == null)
			return 0;
		return 1;
	}

	@Override
	public int numVertices() {
		return adjacencyM.size();
	}

	@Override
	public Iterable<V> vertices() {
		return adjacencyM.keySet();
	}

	@Override
	public int numEdges() {
		int numEdges = 0;
		for (V vertex : vertices()) {
			numEdges += adjacencyM.get(vertex).size();
		}
		return numEdges;
	}

	@Override
	public boolean isDirected() {
		return f;
	}

	@Override
	public boolean isWeighted() {
		return t;
	}

	@Override
	public int outDegree(V v) {
		return adjacencyM.containsKey(v) ? ((ArrayList<V>) outgoingNeighbors(v)).size() : -1;
	}

	@Override
	public int inDegree(V v) {
		return adjacencyM.containsKey(v) ? ((ArrayList<V>) incomingNeighbors(v)).size() : -1;
	}

	@Override
	public Iterable<V> outgoingNeighbors(V v) {
		return adjacencyM.containsKey(v) ? adjacencyM.get(v) : null;
	}

	@Override
	public Iterable<V> incomingNeighbors(V v) {
		if (!adjacencyM.containsKey(v))
			return null;
		ArrayList<V> neighbors = new ArrayList<V>();
		for (V vertex : vertices())
			if (adjacencyM.get(vertex).contains(v))
				neighbors.add(vertex);
		return neighbors;
	}
}